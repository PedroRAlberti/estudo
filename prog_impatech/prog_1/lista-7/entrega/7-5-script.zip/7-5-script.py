import vector3d as vector

V1 = vector.vector3d([1,0,1])
V2 = vector.vector3d([-1,2,3])

print(5*V1-4*V2)
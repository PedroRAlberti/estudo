class point2D():
    def __init__(self,x,y):
        self.coord = tupla = (x,y)

    def __str__(self):
        return str(self.coord)

class polygon():
    def __init__(self,lista,cor):
        self.cor = cor
        self.lista = lista

    def __str__(self):
        string = []
        for i in self.lista:
            string.append(str(i))
        return str(" , ".join(string)) + " , " + str(self.cor)

class polygons():
    def __init__(self):
        self.len = 0
        self.poligonos = []

    def add_poligono(self,poligono,nome):
        self.len += 1
        lista = []
        lista.append(nome)
        lista.append([str(poligono)])
        self.poligonos.append(lista)
    
    def remove_polygon(self,nome):
        for i in range(self.len):
            if self.poligonos[i][0] == nome:
                self.poligonos.remove(self.poligonos[i])
                self.len -= 1
                return
            
    def save_to_file(self,nome):
        f = open(nome, 'w')
        # for i in range(5):
        #     f.write(str(i))
        f.write(str(self.poligonos))
        f.close()

    def load_from_file(self,nome):
        f = open(nome,'r')
        text = f.read()
        f.close()
        self.poligonos = text
        return 

    def __str__(self):
        lista = []
        for i in range(self.len):
            lista.append(self.poligonos[i])
        return  str((lista))
    
A = point2D(1,2)
B = point2D(1,5)
C = point2D(4,5)
D = point2D(4,2)
E = point2D(10,10)
poligono4 = polygon([A,B,C,D,E],"roxo")
poligono1 = polygon([A,B,C,D],"azul")
poligono2 = polygon([A,C,D],"amarelo")
poligono3 = polygon([A,C],"laranja")

poligonos = polygons()
poligonos.add_poligono(poligono1,"quadrado")
poligonos.add_poligono(poligono2,"triangulo")
poligonos.add_poligono(poligono3,"reta")
poligonos.add_poligono(poligono4,"pentagono")
print(poligonos)
poligonos.remove_polygon("reta")
print(poligonos)
poligonos.save_to_file("alb")
poligonos2 = polygons()
poligonos2.load_from_file("alb")
poligonos2.save_to_file("alb.copy")